# FF DRAG PRO

A drag-headshot trainer and Free Fire India companion app for Android, tuned for the **Redmi 14C 5G** (HyperOS, Android 14 → 15). It targets Android 15 (API 35) and runs on Android 8.0+.

<img src="docs/icon-preview.png" width="96" alt="App icon">

## What it does

| Feature | How it works |
|---|---|
| **Launch Free Fire India** | Finds the installed game by its launcher name ("Free Fire", preferring "India") or Garena's `com.dts.*` package and opens it with a normal launch intent. If not found: *Choose game* (pick any installed app) or *Get from Play Store*. |
| **Drag-headshot trainer** | Full-screen landscape drill. A target appears with the crosshair at chest height; thumb down anywhere, swipe up, lift to shoot. Scored as Headshot / Body (stopped short) / Over-drag / Miss / Too slow. |
| **Distance + direction teaching** | Orange guide arrow from crosshair to head with the remaining finger distance in **millimetres** (uses the screen's real DPI), dashed head zone, finger trail, and per-shot feedback such as "OVER-DRAG · 2.4 mm too far". |
| **Weapon categories** | Shotgun, SMG, Assault Rifle, Pistol, Sniper: different target distance, head tolerance, simulated recoil climb while held, sideways movement and swipe-time target. |
| **Adjustable speed** | Levels 1–5: spawn delay, strafing speed and reaction window (2.6 s → 1.0 s). Plus drag sensitivity 50–200 % and 10–50 targets per session. |
| **Accuracy + reaction tracking** | Headshot %, reaction time, swipe time, average vertical error, consistency (error spread), personal average headshot swipe per weapon, coaching tip. History of the last 100 sessions, stored on the phone only. |
| **Floating gaming panel (optional)** | Small "FF" bubble over any app. Tap: Open Free Fire, Drag trainer, Drag guide card (tips plus your personal swipe), Hide, Close. Drag to any edge (snaps and remembers the side); adjustable opacity; lock position. |
| **Guide** | Fundamentals, weapon-specific tips, how scoring works, your measured swipe per weapon. |

### Fair play (by design)
- No injection, no memory or file access to Free Fire, no screen reading.
- No automated input, aiming or targeting: the app never sends touches.
- The floating panel only receives touches on the bubble itself (`FLAG_NOT_FOCUSABLE`, wrap-content window); every other touch goes to the game.
- No anti-cheat interaction. Not affiliated with Garena.

### Performance
- No runtime libraries: Android framework + Kotlin stdlib only. Release build is minified and resource-shrunk.
- The trainer animates only while a session runs; idle screens don't redraw. Sessions pause automatically when you leave.
- No background work. The single service exists only while the floating panel is switched on (Android requires a foreground service plus notification for a persistent overlay); it holds no timers, sensors or wake locks.

## Build

### Option A: Android Studio (recommended)
1. Install Android Studio (any 2024.2+ release) with **Android SDK 35**.
2. *File → Open* → select the `FFDragPro` folder. Let Gradle sync (it downloads Gradle 8.10.2, AGP 8.7.3, Kotlin 2.0.21). If Android Studio offers an AGP upgrade you can accept it or skip it.
3. Plug in the phone (see USB debugging below) → press **Run ▶**.
4. Or build an APK: *Build → Build App Bundle(s) / APK(s) → Build APK(s)*. Output: `app/build/outputs/apk/debug/app-debug.apk`.

### Option B: command line
Requires JDK 17 and the Android SDK (`ANDROID_HOME` set, or `sdk.dir=...` in `local.properties`).
```bash
./gradlew testDebugUnitTest      # unit tests for the scoring logic
./gradlew assembleDebug          # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease        # app/build/outputs/apk/release/app-release.apk (minified)
```
The release APK is signed with your local debug key so it installs directly. Use your own keystore before distributing it.

### Option C: build in the cloud with GitHub (no PC setup)
1. Create a new GitHub repository and push this folder to it.
2. Open the **Actions** tab. The *Build APK* workflow runs automatically (or press *Run workflow*).
3. When it finishes, download the **FF-DRAG-PRO-apk** artifact (a zip containing the debug and release APKs).

## Install on Redmi 14C 5G
1. Copy `app-release.apk` (or `app-debug.apk`) to the phone and tap it. Allow *Install unknown apps* for your file manager when HyperOS asks.
   Or over USB: enable *Settings → About phone → tap OS version 7 times*, then *Additional settings → Developer options → USB debugging*, and run `adb install -r app-release.apk`.
2. Open **FF DRAG PRO**.
3. To use the floating panel, turn on the switch and grant:
   - **Display over other apps / Display pop-up window** (the app opens this screen for you).
   - **Notifications** (optional; shows the panel notification with its Close button).
   - On HyperOS also: **App permissions (Redmi / HyperOS)** button → *Other permissions* → **Display pop-up windows while running in the background**. Without it, HyperOS may block the panel's *Drag trainer* / *Open Free Fire* shortcuts while the game is open.

## Using it
1. **Trainer:** pick a weapon on the home screen. Press START, put your fire thumb down when the target appears, swipe up to the head and lift. Start at speed 1–2 with the guide on; turn the guide off once your headshot % is above about 70 %.
2. **Match your game feel:** under *Settings → Drag sensitivity*, raise the value if the in-game aim moves further per swipe than the trainer, lower it if less.
3. **Before a match:** turn on the floating panel → *Launch Free Fire India*. Drag the bubble to an edge free of your HUD controls; lower its opacity if needed. Tap the bubble → *Drag guide* to see your personal swipe length per weapon.

## Project layout
```
app/src/main/java/com/ffdragpro/app/
  MainActivity.kt      home: game card, floating-panel switch, weapon shortcuts
  TrainerActivity.kt   full-screen trainer host, HUD, results
  TrainerView.kt       drill engine: spawning, input, recoil, drawing, guide
  DragEvaluator.kt     pure scoring logic + session summary (unit tested)
  Weapon.kt            weapon categories and tips
  OverlayService.kt    optional floating panel (foreground service)
  GameLauncher.kt      find / launch the game, Play Store fallback
  GuideActivity.kt, StatsActivity.kt, SettingsActivity.kt, Prefs.kt
app/src/main/res/      layouts, strings, theme, adaptive icon (vector)
app/src/test/          JUnit tests (15) for scoring and coaching logic
.github/workflows/     cloud APK build
```

## Notes and limits
- The trainer is a motion drill for swipe length, direction and timing. It does not reproduce Free Fire's aim assist or exact weapon behaviour; weapon values are training parameters.
- Free Fire India's package name is not hard-coded. If auto-detect picks the wrong app (for example Free Fire MAX), use *Choose game*.
- Android 15's edge-to-edge enforcement is opted out in `values-v35/themes.xml` so regular screens never sit under the system bars; the trainer is intentionally full screen.
