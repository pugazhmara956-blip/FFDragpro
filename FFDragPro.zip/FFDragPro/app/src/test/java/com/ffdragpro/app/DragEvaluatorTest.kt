package com.ffdragpro.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DragEvaluatorTest {

    // Head centred at (500, 200), radius 20. Body from y=225 to y=500, half width 30.
    private val target = TargetGeometry(
        centerX = 500f, headCenterY = 200f, headRadius = 20f,
        bodyTop = 225f, bodyBottom = 500f, bodyHalfWidth = 30f,
    )

    @Test fun centreOfHeadIsHeadshot() =
        assertEquals(ShotOutcome.HEADSHOT, DragEvaluator.classify(500f, 200f, target, 1f))

    @Test fun toleranceWidensHeadZone() {
        // 24 px from the centre: outside radius 20, inside 20 * 1.3 = 26.
        assertEquals(ShotOutcome.OVERDRAG, DragEvaluator.classify(500f, 176f, target, 1f))
        assertEquals(ShotOutcome.HEADSHOT, DragEvaluator.classify(500f, 176f, target, 1.3f))
    }

    @Test fun stoppingAtChestIsBody() =
        assertEquals(ShotOutcome.BODY, DragEvaluator.classify(505f, 300f, target, 1f))

    @Test fun neckGapCountsAsBody() =
        assertEquals(ShotOutcome.BODY, DragEvaluator.classify(500f, 222f, target, 1f))

    @Test fun goingAboveHeadIsOverdrag() =
        assertEquals(ShotOutcome.OVERDRAG, DragEvaluator.classify(510f, 120f, target, 1f))

    @Test fun farToTheSideIsMiss() =
        assertEquals(ShotOutcome.MISS, DragEvaluator.classify(600f, 200f, target, 1f))

    @Test fun belowTheFeetIsMiss() =
        assertEquals(ShotOutcome.MISS, DragEvaluator.classify(500f, 560f, target, 1f))

    @Test fun pxToMmUsesDpi() =
        assertEquals(25.4f, DragEvaluator.pxToMm(300f, 300f), 0.001f)

    private fun rec(o: ShotOutcome, reaction: Long = 300, swipe: Long = 200, err: Float = 0f, finger: Float = 10f) =
        ShotRecord(o, reaction, swipe, err, finger, 10f)

    @Test fun summaryCountsAndAverages() {
        val records = listOf(
            rec(ShotOutcome.HEADSHOT, reaction = 200, swipe = 100, err = 0.5f, finger = 9f),
            rec(ShotOutcome.HEADSHOT, reaction = 400, swipe = 300, err = -0.5f, finger = 11f),
            rec(ShotOutcome.OVERDRAG, reaction = 300, swipe = 200, err = 3f),
            rec(ShotOutcome.BODY, reaction = 300, swipe = 200, err = -2f),
            ShotRecord(ShotOutcome.TIMEOUT, -1, 0, 0f, 0f, 10f),
        )
        val s = SessionSummary.from(records)
        assertEquals(5, s.shots)
        assertEquals(2, s.headshots)
        assertEquals(1, s.overdrag)
        assertEquals(1, s.body)
        assertEquals(1, s.timeout)
        assertEquals(40, s.headshotPct)
        // Timeouts are excluded from reaction and swipe averages.
        assertEquals(300, s.avgReactionMs)
        assertEquals(200, s.avgSwipeMs)
        // Mean signed error of the two non-headshot attempts: (3 + -2) / 2.
        assertEquals(0.5f, s.meanSignedErrorMm, 0.001f)
        assertEquals(10f, s.avgHeadshotSwipeMm!!, 0.001f)
    }

    @Test fun noHeadshotsGivesNullSwipe() {
        val s = SessionSummary.from(listOf(rec(ShotOutcome.MISS)))
        assertNull(s.avgHeadshotSwipeMm)
        assertEquals(0, s.headshotPct)
    }

    @Test fun emptySessionIsSafe() {
        val s = SessionSummary.from(emptyList())
        assertEquals(0, s.shots)
        assertEquals(0, s.headshotPct)
        assertEquals("No shots recorded.", s.coachingTip(Weapon.SMG))
    }

    @Test fun tipPointsAtOverdrag() {
        val records = List(6) { rec(ShotOutcome.OVERDRAG, err = 2.5f) } + List(4) { rec(ShotOutcome.HEADSHOT) }
        val tip = SessionSummary.from(records).coachingTip(Weapon.SMG)
        assertTrue(tip, tip.contains("over the head"))
        assertTrue(tip, tip.contains("2.5 mm"))
    }

    @Test fun tipPointsAtStoppingShort() {
        val records = List(6) { rec(ShotOutcome.BODY, err = -1.5f) } + List(4) { rec(ShotOutcome.HEADSHOT) }
        val tip = SessionSummary.from(records).coachingTip(Weapon.AR)
        assertTrue(tip, tip.contains("below the head"))
        assertTrue(tip, tip.contains("1.5 mm"))
    }

    @Test fun tipFlagsSlowSwipes() {
        val records = List(10) { rec(ShotOutcome.HEADSHOT, swipe = 900) }
        val tip = SessionSummary.from(records).coachingTip(Weapon.SHOTGUN)
        assertTrue(tip, tip.contains("900 ms"))
    }

    @Test fun weaponCycleWrapsAround() {
        assertEquals(Weapon.SMG, Weapon.SHOTGUN.next())
        assertEquals(Weapon.SHOTGUN, Weapon.SNIPER.next())
        assertEquals(Weapon.AR, Weapon.fromName("AR"))
        assertNull(Weapon.fromName("ROCKET"))
    }
}
