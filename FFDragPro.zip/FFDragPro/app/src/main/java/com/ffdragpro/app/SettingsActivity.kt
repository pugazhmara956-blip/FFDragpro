package com.ffdragpro.app

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = Prefs(this)

        bindSeek(R.id.seekSensitivity, R.id.tvSensitivity, 50, 200, 5, prefs.sensitivityPct,
            { prefs.sensitivityPct = it }) { getString(R.string.set_sensitivity, it) }
        bindSeek(R.id.seekSpeed, R.id.tvSpeed, 1, 5, 1, prefs.speedLevel,
            { prefs.speedLevel = it }) { getString(R.string.set_speed, it) }
        bindSeek(R.id.seekRounds, R.id.tvRounds, 10, 50, 5, prefs.rounds,
            { prefs.rounds = it }) { getString(R.string.set_rounds, it) }
        bindSeek(R.id.seekOverlayAlpha, R.id.tvOverlayAlpha, 30, 100, 5, prefs.overlayAlpha,
            {
                prefs.overlayAlpha = it
                OverlayService.refresh(this)
            }) { getString(R.string.set_overlay_alpha, it) }

        bindSwitch(R.id.swGuide, prefs.showGuide) { prefs.showGuide = it }
        bindSwitch(R.id.swHaptics, prefs.haptics) { prefs.haptics = it }
        bindSwitch(R.id.swLockOverlay, prefs.overlayLocked) { prefs.overlayLocked = it }

        findViewById<Button>(R.id.btnResetOverlay).setOnClickListener {
            prefs.overlaySideRight = false
            prefs.overlayY = -1
            OverlayService.refresh(this)
            Toast.makeText(this, R.string.set_overlay_reset_done, Toast.LENGTH_SHORT).show()
        }
    }

    private fun bindSeek(
        seekId: Int,
        labelId: Int,
        min: Int,
        max: Int,
        step: Int,
        current: Int,
        onChange: (Int) -> Unit,
        label: (Int) -> String,
    ) {
        val seek = findViewById<SeekBar>(seekId)
        val tv = findViewById<TextView>(labelId)
        seek.max = (max - min) / step
        seek.progress = ((current - min) / step).coerceIn(0, seek.max)
        tv.text = label(current)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val value = min + progress * step
                tv.text = label(value)
                if (fromUser) onChange(value)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
        })
    }

    private fun bindSwitch(id: Int, current: Boolean, onChange: (Boolean) -> Unit) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = current
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }
}
