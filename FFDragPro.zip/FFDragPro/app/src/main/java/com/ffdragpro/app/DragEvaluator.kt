package com.ffdragpro.app

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Pure scoring logic (no Android imports) so it can be unit tested on the JVM. */

enum class ShotOutcome(val label: String) {
    HEADSHOT("Headshot"),
    BODY("Body"),
    OVERDRAG("Over-drag"),
    MISS("Miss"),
    TIMEOUT("Too slow"),
}

/** Target geometry in world pixels. Y grows downward (Android canvas convention). */
data class TargetGeometry(
    val centerX: Float,
    val headCenterY: Float,
    val headRadius: Float,
    val bodyTop: Float,
    val bodyBottom: Float,
    val bodyHalfWidth: Float,
)

/**
 * One shot.
 * [verticalErrorMm]: finger millimetres between where the shot landed and the head centre.
 * Positive = over-drag (above the head), negative = stopped short (below the head).
 */
data class ShotRecord(
    val outcome: ShotOutcome,
    val reactionMs: Long,
    val swipeMs: Long,
    val verticalErrorMm: Float,
    val fingerSwipeMm: Float,
    val requiredSwipeMm: Float,
)

object DragEvaluator {

    fun classify(x: Float, y: Float, t: TargetGeometry, headTolerance: Float): ShotOutcome {
        val r = t.headRadius * headTolerance
        val dx = x - t.centerX
        val dy = y - t.headCenterY
        if (dx * dx + dy * dy <= r * r) return ShotOutcome.HEADSHOT
        val halfWidth = max(t.bodyHalfWidth, r)
        if (abs(dx) <= halfWidth) {
            if (y < t.headCenterY) return ShotOutcome.OVERDRAG
            if (y <= t.bodyBottom) return ShotOutcome.BODY
        }
        return ShotOutcome.MISS
    }

    fun pxToMm(px: Float, dpi: Float): Float = px / dpi * 25.4f
}

data class SessionSummary(
    val shots: Int,
    val headshots: Int,
    val body: Int,
    val overdrag: Int,
    val miss: Int,
    val timeout: Int,
    val avgReactionMs: Int,
    val avgSwipeMs: Int,
    /** Mean signed error of non-headshot attempts (+ over, - short). */
    val meanSignedErrorMm: Float,
    val meanAbsErrorMm: Float,
    /** Standard deviation of the vertical error: lower = more consistent swipes. */
    val errorSpreadMm: Float,
    /** Average finger swipe length on headshots, or null if there were none. */
    val avgHeadshotSwipeMm: Float?,
) {
    val headshotPct: Int get() = if (shots == 0) 0 else (headshots * 100f / shots).roundToInt()

    fun coachingTip(weapon: Weapon): String {
        if (shots == 0) return "No shots recorded."
        val parts = mutableListOf<String>()
        when {
            headshotPct >= 75 ->
                parts += "Excellent control. Raise the training speed to keep improving."
            overdrag > body && overdrag >= miss ->
                parts += String.format(Locale.US, "Most misses went over the head. Shorten your swipe by about %.1f mm.", abs(meanSignedErrorMm))
            body >= overdrag && body >= miss && body > 0 ->
                parts += String.format(Locale.US, "Most misses stopped below the head. Swipe about %.1f mm further.", abs(meanSignedErrorMm))
            miss > 0 ->
                parts += "Several shots went wide. Line up sideways before the upward flick."
        }
        if (timeout * 4 > shots) parts += "Start sooner: put your thumb down as soon as the target appears."
        if (avgSwipeMs > weapon.maxSwipeMs) {
            parts += String.format(Locale.US, "Your swipe takes %d ms; aim for under %d ms with the %s.", avgSwipeMs, weapon.maxSwipeMs, weapon.label)
        }
        if (parts.isEmpty()) parts += "Keep practising: consistency comes from repeating the same swipe length."
        return parts.joinToString(" ")
    }

    companion object {
        fun from(records: List<ShotRecord>): SessionSummary {
            val attempted = records.filter { it.outcome != ShotOutcome.TIMEOUT }
            val nonHeadshots = attempted.filter { it.outcome != ShotOutcome.HEADSHOT }
            val headshotRecords = records.filter { it.outcome == ShotOutcome.HEADSHOT }
            val errors = attempted.map { it.verticalErrorMm }
            return SessionSummary(
                shots = records.size,
                headshots = headshotRecords.size,
                body = records.count { it.outcome == ShotOutcome.BODY },
                overdrag = records.count { it.outcome == ShotOutcome.OVERDRAG },
                miss = records.count { it.outcome == ShotOutcome.MISS },
                timeout = records.count { it.outcome == ShotOutcome.TIMEOUT },
                avgReactionMs = if (attempted.isEmpty()) 0 else attempted.map { it.reactionMs }.average().roundToInt(),
                avgSwipeMs = if (attempted.isEmpty()) 0 else attempted.map { it.swipeMs }.average().roundToInt(),
                meanSignedErrorMm = if (nonHeadshots.isEmpty()) 0f else nonHeadshots.map { it.verticalErrorMm }.average().toFloat(),
                meanAbsErrorMm = if (errors.isEmpty()) 0f else errors.map { abs(it) }.average().toFloat(),
                errorSpreadMm = stdDev(errors),
                avgHeadshotSwipeMm = if (headshotRecords.isEmpty()) null else headshotRecords.map { it.fingerSwipeMm }.average().toFloat(),
            )
        }

        private fun stdDev(values: List<Float>): Float {
            if (values.size < 2) return 0f
            val mean = values.average()
            val sumSq = values.sumOf { (it - mean) * (it - mean) }
            return sqrt(sumSq / (values.size - 1)).toFloat()
        }
    }
}
