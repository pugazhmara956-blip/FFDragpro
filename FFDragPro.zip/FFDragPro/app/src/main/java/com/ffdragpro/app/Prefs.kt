package com.ffdragpro.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import kotlin.math.max

data class HistoryEntry(
    val timeMs: Long,
    val weapon: Weapon,
    val speed: Int,
    val summary: SessionSummary,
)

/** Settings and training history, stored locally in SharedPreferences. Nothing leaves the device. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("ffdragpro_prefs", Context.MODE_PRIVATE)

    var weapon: Weapon
        get() = Weapon.fromName(sp.getString(K_WEAPON, null)) ?: Weapon.SMG
        set(value) = sp.edit().putString(K_WEAPON, value.name).apply()

    var speedLevel: Int
        get() = sp.getInt(K_SPEED, 2).coerceIn(1, 5)
        set(value) = sp.edit().putInt(K_SPEED, value.coerceIn(1, 5)).apply()

    var rounds: Int
        get() = sp.getInt(K_ROUNDS, 20).coerceIn(10, 50)
        set(value) = sp.edit().putInt(K_ROUNDS, value.coerceIn(10, 50)).apply()

    /** Drag sensitivity in percent: how far the crosshair moves per millimetre of finger movement. */
    var sensitivityPct: Int
        get() = sp.getInt(K_SENS, 100).coerceIn(50, 200)
        set(value) = sp.edit().putInt(K_SENS, value.coerceIn(50, 200)).apply()

    var showGuide: Boolean
        get() = sp.getBoolean(K_GUIDE, true)
        set(value) = sp.edit().putBoolean(K_GUIDE, value).apply()

    var haptics: Boolean
        get() = sp.getBoolean(K_HAPTICS, true)
        set(value) = sp.edit().putBoolean(K_HAPTICS, value).apply()

    var overlayAlpha: Int
        get() = sp.getInt(K_OV_ALPHA, 85).coerceIn(30, 100)
        set(value) = sp.edit().putInt(K_OV_ALPHA, value.coerceIn(30, 100)).apply()

    var overlayLocked: Boolean
        get() = sp.getBoolean(K_OV_LOCK, false)
        set(value) = sp.edit().putBoolean(K_OV_LOCK, value).apply()

    /** Which screen edge the floating bubble is docked to. */
    var overlaySideRight: Boolean
        get() = sp.getBoolean(K_OV_RIGHT, false)
        set(value) = sp.edit().putBoolean(K_OV_RIGHT, value).apply()

    /** Bubble Y position in pixels, or -1 for the default position. */
    var overlayY: Int
        get() = sp.getInt(K_OV_Y, -1)
        set(value) = sp.edit().putInt(K_OV_Y, value).apply()

    /** Package chosen by the user as "the game", or null to auto-detect Free Fire. */
    var gamePackage: String?
        get() = sp.getString(K_GAME, null)
        set(value) = sp.edit().putString(K_GAME, value).apply()

    // ---- History -------------------------------------------------------------------------

    fun addSession(weapon: Weapon, speed: Int, s: SessionSummary, timeMs: Long = System.currentTimeMillis()) {
        val arr = readHistoryArray()
        val o = JSONObject()
        o.put("t", timeMs)
        o.put("w", weapon.name)
        o.put("sp", speed)
        o.put("shots", s.shots)
        o.put("hs", s.headshots)
        o.put("body", s.body)
        o.put("over", s.overdrag)
        o.put("miss", s.miss)
        o.put("to", s.timeout)
        o.put("rx", s.avgReactionMs)
        o.put("sw", s.avgSwipeMs)
        o.put("mse", s.meanSignedErrorMm.toDouble())
        o.put("mae", s.meanAbsErrorMm.toDouble())
        o.put("spr", s.errorSpreadMm.toDouble())
        s.avgHeadshotSwipeMm?.let { o.put("hsw", it.toDouble()) }
        arr.put(o)
        val trimmed = JSONArray()
        for (i in max(0, arr.length() - MAX_HISTORY) until arr.length()) trimmed.put(arr.get(i))
        sp.edit().putString(K_HISTORY, trimmed.toString()).apply()
    }

    /** Newest first. */
    fun history(): List<HistoryEntry> {
        val arr = readHistoryArray()
        val out = ArrayList<HistoryEntry>(arr.length())
        for (i in arr.length() - 1 downTo 0) {
            try {
                val o = arr.getJSONObject(i)
                val weapon = Weapon.fromName(o.getString("w")) ?: continue
                val summary = SessionSummary(
                    shots = o.getInt("shots"),
                    headshots = o.getInt("hs"),
                    body = o.getInt("body"),
                    overdrag = o.getInt("over"),
                    miss = o.getInt("miss"),
                    timeout = o.getInt("to"),
                    avgReactionMs = o.getInt("rx"),
                    avgSwipeMs = o.getInt("sw"),
                    meanSignedErrorMm = o.getDouble("mse").toFloat(),
                    meanAbsErrorMm = o.getDouble("mae").toFloat(),
                    errorSpreadMm = o.getDouble("spr").toFloat(),
                    avgHeadshotSwipeMm = if (o.has("hsw")) o.getDouble("hsw").toFloat() else null,
                )
                out += HistoryEntry(o.getLong("t"), weapon, o.getInt("sp"), summary)
            } catch (e: JSONException) {
                // Skip a damaged entry rather than losing the whole history.
            }
        }
        return out
    }

    /** Adds the finger swipe lengths of headshots to the per-weapon running average. */
    fun addHeadshotSwipes(weapon: Weapon, records: List<ShotRecord>) {
        val hits = records.filter { it.outcome == ShotOutcome.HEADSHOT }
        if (hits.isEmpty()) return
        val sum = sp.getFloat(swipeSumKey(weapon), 0f) + hits.sumOf { it.fingerSwipeMm.toDouble() }.toFloat()
        val count = sp.getInt(swipeCountKey(weapon), 0) + hits.size
        sp.edit().putFloat(swipeSumKey(weapon), sum).putInt(swipeCountKey(weapon), count).apply()
    }

    /** Average headshot swipe in mm and the number of headshots it is based on, or null. */
    fun headshotSwipe(weapon: Weapon): Pair<Float, Int>? {
        val count = sp.getInt(swipeCountKey(weapon), 0)
        if (count == 0) return null
        return Pair(sp.getFloat(swipeSumKey(weapon), 0f) / count, count)
    }

    fun clearHistory() {
        val e = sp.edit().remove(K_HISTORY)
        for (w in Weapon.entries) e.remove(swipeSumKey(w)).remove(swipeCountKey(w))
        e.apply()
    }

    private fun readHistoryArray(): JSONArray = try {
        JSONArray(sp.getString(K_HISTORY, "[]") ?: "[]")
    } catch (e: JSONException) {
        JSONArray()
    }

    private fun swipeSumKey(w: Weapon) = "swipe_sum_${w.name}"
    private fun swipeCountKey(w: Weapon) = "swipe_cnt_${w.name}"

    private companion object {
        const val MAX_HISTORY = 100
        const val K_WEAPON = "weapon"
        const val K_SPEED = "speed"
        const val K_ROUNDS = "rounds"
        const val K_SENS = "sensitivity"
        const val K_GUIDE = "show_guide"
        const val K_HAPTICS = "haptics"
        const val K_OV_ALPHA = "overlay_alpha"
        const val K_OV_LOCK = "overlay_locked"
        const val K_OV_RIGHT = "overlay_right"
        const val K_OV_Y = "overlay_y"
        const val K_GAME = "game_package"
        const val K_HISTORY = "history"
    }
}
