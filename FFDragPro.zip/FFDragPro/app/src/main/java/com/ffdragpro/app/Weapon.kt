package com.ffdragpro.app

/**
 * Weapon categories used by the trainer. The numbers shape the practice drill
 * (target distance, head tolerance, aim climb while the finger is held); they are
 * training parameters, not values read from Free Fire.
 */
enum class Weapon(
    val label: String,
    val examples: String,
    /** Target size multiplier. Close-range classes show bigger targets, so the chest-to-head swipe is longer. */
    val rangeScale: Float,
    /** Multiplier on the head radius that still counts as a headshot. */
    val headTolerance: Float,
    /** Upward aim drift while the finger is down, as a fraction of the view height per second (simulated recoil). */
    val recoilPerSec: Float,
    /** Swipes slower than this are flagged as slow for this class. */
    val maxSwipeMs: Long,
    /** Multiplier on sideways target movement. */
    val strafeFactor: Float,
    val tips: List<String>,
) {
    SHOTGUN(
        "Shotgun", "M1887, M1014, MAG-7",
        rangeScale = 1.25f, headTolerance = 1.30f, recoilPerSec = 0.00f, maxSwipeMs = 450L, strafeFactor = 1.2f,
        tips = listOf(
            "Close range makes the target big, so the chest-to-head swipe is the longest of any class.",
            "Press fire and flick up in one motion. Do not pause before the swipe.",
            "Against a strafing enemy, a fast short flick works better than a slow careful drag.",
        ),
    ),
    SMG(
        "SMG", "MP40, UMP, MP5",
        rangeScale = 1.0f, headTolerance = 1.10f, recoilPerSec = 0.06f, maxSwipeMs = 600L, strafeFactor = 1.0f,
        tips = listOf(
            "Medium swipe length. Stop the flick as soon as the crosshair reaches head level.",
            "The weapon keeps firing while you hold, and recoil adds climb, so swipe slightly less than the gap you see.",
            "Track sideways first, then flick up.",
        ),
    ),
    AR(
        "Assault Rifle", "M4A1, AK, SCAR, Groza",
        rangeScale = 0.85f, headTolerance = 1.0f, recoilPerSec = 0.12f, maxSwipeMs = 700L, strafeFactor = 0.8f,
        tips = listOf(
            "Recoil pushes the aim up while you hold fire. Swipe less than the visible gap and let recoil finish the climb.",
            "Targets are further away, so the swipe is shorter than with an SMG.",
            "Short bursts keep the climb predictable.",
        ),
    ),
    PISTOL(
        "Pistol", "Desert Eagle, M500",
        rangeScale = 0.95f, headTolerance = 1.0f, recoilPerSec = 0.18f, maxSwipeMs = 500L, strafeFactor = 0.9f,
        tips = listOf(
            "Strong kick: one short flick per shot, then bring the crosshair back to the chest.",
            "Release right after reaching the head. Holding longer drifts the aim over the target.",
        ),
    ),
    SNIPER(
        "Sniper", "AWM, M82B, Kar98k",
        rangeScale = 0.60f, headTolerance = 0.90f, recoilPerSec = 0.00f, maxSwipeMs = 900L, strafeFactor = 0.4f,
        tips = listOf(
            "Long range: the head is small and the swipe is very short. Precision beats speed.",
            "Line up sideways first, then make a small upward correction.",
        ),
    );

    fun next(): Weapon = entries[(ordinal + 1) % entries.size]

    companion object {
        fun fromName(name: String?): Weapon? = entries.firstOrNull { it.name == name }
    }
}
