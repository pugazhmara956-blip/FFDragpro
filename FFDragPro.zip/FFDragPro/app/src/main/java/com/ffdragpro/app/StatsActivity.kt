package com.ffdragpro.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class StatsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var tvOverview: TextView
    private lateinit var historyList: LinearLayout
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)
        prefs = Prefs(this)
        tvOverview = findViewById(R.id.tvOverview)
        historyList = findViewById(R.id.historyList)
        tvEmpty = findViewById(R.id.tvEmpty)
        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.stats_clear_title)
                .setMessage(R.string.stats_clear_message)
                .setPositiveButton(R.string.stats_clear_confirm) { _, _ ->
                    prefs.clearHistory()
                    render()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val history = prefs.history()
        tvEmpty.visibility = if (history.isEmpty()) View.VISIBLE else View.GONE

        tvOverview.text = if (history.isEmpty()) {
            getString(R.string.stats_no_data)
        } else {
            buildString {
                for (w in Weapon.entries) {
                    val sessions = history.filter { it.weapon == w }
                    if (sessions.isEmpty()) continue
                    val best = sessions.maxOf { it.summary.headshotPct }
                    val last = sessions.first().summary.headshotPct
                    val avgReaction = sessions.map { it.summary.avgReactionMs }.average().toInt()
                    val swipe = prefs.headshotSwipe(w)
                    append(String.format(Locale.US, "%s: %d sessions · last %d%% · best %d%% · reaction %d ms",
                        w.label, sessions.size, last, best, avgReaction))
                    if (swipe != null) append(String.format(Locale.US, " · headshot swipe %.1f mm", swipe.first))
                    append('\n')
                }
            }.trimEnd()
        }

        historyList.removeAllViews()
        val dateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        for (entry in history.take(30)) {
            val s = entry.summary
            val item = layoutInflater.inflate(R.layout.item_history, historyList, false) as TextView
            item.text = String.format(
                Locale.US,
                "%s  ·  %s  ·  speed %d\nHeadshots %d%% (%d/%d) · over-drag %d · short %d · wide %d · slow %d\nReaction %d ms · swipe %d ms · error %.1f mm",
                dateFormat.format(Date(entry.timeMs)), entry.weapon.label, entry.speed,
                s.headshotPct, s.headshots, s.shots, s.overdrag, s.body, s.miss, s.timeout,
                s.avgReactionMs, s.avgSwipeMs, s.meanAbsErrorMm
            )
            historyList.addView(item)
        }
    }
}
