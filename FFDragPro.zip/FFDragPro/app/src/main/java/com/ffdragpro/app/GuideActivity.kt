package com.ffdragpro.app

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class GuideActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var tvWeaponTitle: TextView
    private lateinit var tvWeaponTips: TextView
    private lateinit var tvPersonal: TextView
    private val tabs = ArrayList<Button>()
    private var selected = Weapon.SMG

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guide)
        prefs = Prefs(this)
        selected = prefs.weapon

        tvWeaponTitle = findViewById(R.id.tvWeaponTitle)
        tvWeaponTips = findViewById(R.id.tvWeaponTips)
        tvPersonal = findViewById(R.id.tvPersonal)

        val row = findViewById<LinearLayout>(R.id.weaponTabs)
        for (w in Weapon.entries) {
            val b = layoutInflater.inflate(R.layout.item_tab_button, row, false) as Button
            b.text = w.label
            b.setOnClickListener {
                selected = w
                render()
            }
            row.addView(b)
            tabs += b
        }
        findViewById<Button>(R.id.btnPractice).setOnClickListener {
            prefs.weapon = selected
            startActivity(TrainerActivity.intent(this, selected))
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        tabs.forEachIndexed { i, b -> b.isSelected = Weapon.entries[i] == selected }
        tvWeaponTitle.text = getString(R.string.guide_weapon_title, selected.label, selected.examples)
        tvWeaponTips.text = selected.tips.joinToString("\n\n") { "• $it" }
        val personal = prefs.headshotSwipe(selected)
        tvPersonal.text = if (personal != null) {
            getString(R.string.guide_personal, selected.label, personal.first, personal.second)
        } else {
            getString(R.string.guide_personal_none)
        }
    }
}
