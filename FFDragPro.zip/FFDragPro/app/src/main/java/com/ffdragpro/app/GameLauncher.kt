package com.ffdragpro.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build

/**
 * Finds and opens the game with a normal launcher intent, exactly like tapping its icon.
 * Nothing is read from or written to the game.
 */
object GameLauncher {

    data class GameApp(val packageName: String, val label: String)

    /** Garena's Free Fire apps are published under this package prefix. */
    private const val GARENA_PREFIX = "com.dts."

    fun launchableApps(context: Context): List<GameApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = queryActivities(pm, intent)
        return infos
            .map { GameApp(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun isFreeFire(app: GameApp): Boolean =
        app.label.contains("free fire", ignoreCase = true) || app.packageName.startsWith(GARENA_PREFIX)

    /** Free Fire apps first (Free Fire India before others), then everything else alphabetically. */
    fun sortForPicker(apps: List<GameApp>): List<GameApp> =
        apps.sortedWith(
            compareByDescending<GameApp> { isFreeFire(it) }
                .thenByDescending { it.label.contains("india", ignoreCase = true) }
                .thenBy { it.label.lowercase() }
        )

    /** The user's chosen game if still installed, otherwise the best Free Fire match, otherwise null. */
    fun resolveGame(context: Context, prefs: Prefs): GameApp? {
        val apps = launchableApps(context)
        prefs.gamePackage?.let { saved -> apps.firstOrNull { it.packageName == saved }?.let { return it } }
        return sortForPicker(apps.filter { isFreeFire(it) }).firstOrNull()
    }

    fun launch(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }
    }

    /** Opens the Play Store search for Free Fire India. */
    fun openStore(context: Context) {
        val query = Uri.encode("Free Fire India")
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$query&c=apps"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(market)
        } catch (e: ActivityNotFoundException) {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=$query&c=apps"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(web)
            } catch (e2: ActivityNotFoundException) {
                // No store and no browser: nothing else to open.
            }
        }
    }

    private fun queryActivities(pm: PackageManager, intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            queryActivitiesLegacy(pm, intent)
        }

    @Suppress("DEPRECATION")
    private fun queryActivitiesLegacy(pm: PackageManager, intent: Intent): List<ResolveInfo> =
        pm.queryIntentActivities(intent, 0)
}
