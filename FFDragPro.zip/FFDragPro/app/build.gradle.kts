plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ffdragpro.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ffdragpro.app"
        minSdk = 26          // Android 8.0+, covers Redmi 14C 5G (ships with Android 14 / HyperOS)
        targetSdk = 35       // Android 15
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Signed with the local debug key so the release APK installs directly.
            // Replace with your own signing config before publishing anywhere.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // No runtime libraries: the app uses only the Android framework + Kotlin stdlib (small APK).
    testImplementation("junit:junit:4.13.2")
}
