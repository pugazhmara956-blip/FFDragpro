# FF DRAG PRO has no reflection-based libraries.
# Activities, the service and the custom TrainerView (referenced from XML) are kept automatically by AGP.
